/**************************************
 * benchmark.c
 *
 * Programme d'exemple de benchmark
 * pour la fonction malloc.
 * Il peut-être utilisé pour tester
 * l'efficacité d'autres fonctions.
 **************************************/

#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <unistd.h>


/*  _____ _
 * |_   _(_)_ __ ___   ___ _ __
 *   | | | | '_ ` _ \ / _ \ '__|
 *   | | | | | | | | |  __/ |
 *   |_| |_|_| |_| |_|\___|_|
 */

typedef struct timer timer;
struct timer {
  struct timeval start;
};

/*
 * Alloue un nouveau timer.
 * Différents timers sont nécessaires dans le cas de multithreading
 * ou tout simplement dans le cas de plusieurs mesures de temps simultanées.
 */
timer *timer_alloc () {
  timer *t = (timer *) malloc(sizeof(timer));
  if (t == NULL) {
    perror("malloc");
    exit(-1);
  }
  return t;
}

void start_timer (timer *t) {
  gettimeofday(&t->start, NULL);
}
long int stop_timer (timer *t) {
  struct timeval end;
  gettimeofday(&end, NULL);
  return end.tv_sec * 1000000 + end.tv_usec -
    t->start.tv_sec * 1000000 + t->start.tv_usec;
}

void *timer_free (timer *t) {
  free(t);
}

/*  ____                        _
 * |  _ \ ___  ___ ___  _ __ __| | ___ _ __
 * | |_) / _ \/ __/ _ \| '__/ _` |/ _ \ '__|
 * |  _ <  __/ (_| (_) | | | (_| |  __/ |
 * |_| \_\___|\___\___/|_|  \__,_|\___|_|
 */

long int overhead = -1;
long int get_overhead () {
  if (-1 == overhead) {
    timer *t = timer_alloc();
    start_timer(t);
    overhead = stop_timer(t);
    timer_free(t);
    printf("overhead: %ld\n", overhead);
  }
  return overhead;
}

typedef struct recorder recorder;
struct recorder {
  FILE *output;
  long int overhead;
};

recorder *recorder_alloc (char *filename) {
  recorder *rec = (recorder *) malloc(sizeof(recorder));
  if (rec == NULL) {
    perror("malloc");
    return NULL;
  }
  rec->output = fopen(filename, "w");
  if (rec->output == NULL) {
    perror("fopen");
    free(rec);
    return NULL;
  }
  rec->overhead = get_overhead();
  return rec;
}

void write_record (recorder *rec, long int x, long int time) {
  fprintf(rec->output, "%ld, %ld\n", x, time - rec->overhead);
}

void recorder_free (recorder *rec) {
  fclose(rec->output);
  free(rec);
}

#define MAX_SIZE 0x10000000 // 1 MB
#define MAX_ALLOCS 100 // largement assez

int main (int argc, char *argv[]) {
  int i;
  int size;
  void *p;
  timer *t = timer_alloc();

  if (argc < 2) {
    fprintf(stderr, "Missing argument\n");
    return -1;
  }

  // malloc_free
  if (strncmp("--free", argv[1], 7) == 0) {
    printf("free\n");
    recorder *malloc_rec = recorder_alloc("malloc.csv");
    recorder *calloc_rec = recorder_alloc("calloc.csv");
    recorder *free_rec = recorder_alloc("free.csv");
    for (size = 1; size <= MAX_SIZE; size *= 2) {
      start_timer(t);
      p = malloc(size);
      write_record(malloc_rec, size, stop_timer(t));
      if (p == NULL) {
        perror("malloc");
        return -1;
      }
      printf("malloc\t%p\t%p\n", p, sbrk(0));

      start_timer(t);
      free(p);
      write_record(free_rec, size, stop_timer(t));
      printf("free\t%p\t%p\n", p, sbrk(0));

      start_timer(t);
      p = calloc(size, 1);
      write_record(calloc_rec, size, stop_timer(t));
      if (p == NULL) {
        perror("calloc");
        return -1;
      }
      printf("calloc\t%p\t%p\n", p, sbrk(0));

      start_timer(t);
      free(p);
      write_record(free_rec, size, stop_timer(t));
      printf("free\t%p\t%p\n", p, sbrk(0));
    }
    recorder_free(malloc_rec);
    recorder_free(free_rec);
  } else if (strncmp("--nofree", argv[1], 9) == 0) {
    printf("nofree\n");
    // malloc_nofree
    void **allocs = (void **) malloc(sizeof(void*) * MAX_ALLOCS);
    recorder *malloc_nofree_rec = recorder_alloc("malloc_nofree.csv");
    for (size = 1, i = 0; size <= MAX_SIZE; size *= 2, i++) {
      start_timer(t);
      allocs[i] = malloc(size);
      write_record(malloc_nofree_rec, size, stop_timer(t));
      if (allocs[i] == NULL) {
        perror("malloc");
        return -1;
      }
      printf("malloc\t%p\t%p\n", allocs[i], sbrk(0));
    }
    for (size = 1, i = 0; size <= MAX_SIZE; i++, size *= 2) {
      free(allocs[i]);
    }
    recorder_free(malloc_nofree_rec);
  } else if (strncmp("--brk", argv[1], 6) == 0) {
    // brk/sbrk
    recorder *sbrk_rec = recorder_alloc("sbrk.csv");
    recorder *brk_rec = recorder_alloc("brk.csv");
    for (size = 1; size <= MAX_SIZE; size *= 2) {
      start_timer(t);
      p = sbrk(size); // alloc
      write_record(sbrk_rec, size, stop_timer(t));
      if (p == NULL) {
        perror("sbrk");
      }
      start_timer(t);
      int err = brk(p); // free
      write_record(brk_rec, size, stop_timer(t));
      if (err == -1) {
        perror("brk");
      }
    }
    recorder_free(sbrk_rec);
    recorder_free(brk_rec);
  } else {
    fprintf(stderr, "Unknown option\n");
    return -1;
  }

  printf("%p\n", sbrk(0));

  timer_free(t);
  return EXIT_SUCCESS;
}
